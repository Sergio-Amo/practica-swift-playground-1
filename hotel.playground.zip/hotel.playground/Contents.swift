import Foundation

struct Client: Hashable {
    let name: String   // Client name
    let age: Int       // Age on years
    let height: Int    // Height on cm
}

struct Reservation {
    let ID: Int                   // unique (UID)
    let hotelName: String         // Hotel name
    let clientList: Array<Client> // Array of clients
    let lengthOfStay: Int         // Length of stay on days
    let price: Decimal            // Price in € -euro-
    let isBreakfastIncluded: Bool // Breakfast option True/false
}

enum ReservationError: Error {
    case duplicatedID           // There's already a reservation with this ID
    case duplicatedReservation  // Another reservation for that user was found
    case ReservationNotFound    // The reservation for the given ID does not exist
}

// Change Hotel name or prices here
enum HotelDetails {
    static let name: String = "Bootcamp Hotel"
    static let pricePerDay: Decimal = 20
    static let breakfastPriceModifier: Decimal = 1.25
}

class HotelReservationManager {
    // This will serve as an unique ID
    private var uid: Int = 0
    // This array will save all reservations
    private var reservationList: [Int: Reservation] = [:]
    
    /// Computed final price based on the hotel detais and number of clients, length of stay and if breakfast is included, returns Decimal
    private func computeFinalPrice(clientNumber: Int, lengthOfStay: Int, isBreakfastIncluded: Bool) -> Decimal{
        return
            Decimal(clientNumber)
          * HotelDetails.pricePerDay
          * Decimal(lengthOfStay)
          // Apply breakfast price modifier only if isBreakfastIncluded
          * (isBreakfastIncluded ? HotelDetails.breakfastPriceModifier : 1)
    }
    
    /// Using the class reservationList and a given client List search for duplicate clients
    private func checkForDuplicateClients(clientList:Array<Client>) -> Bool {
        // Check if the given clients array contains duplicate entries
        if Set(clientList).count < clientList.count {return true}
        // Check for duplicate clients from given clientList against the reservationList
        for reservation in reservationList.values {
            if (reservation.clientList.contains { client in
                clientList.contains(client)
            }) {return true}
        }
        return false
    }
    /// Using the class reservationList and the current uid value check for possible collisions
    private func checkForDuplicateIds() -> Bool {
        for reservation in reservationList.values {
            if reservation.ID == uid {return true}
        }
        return false
    }
        
    /// Returns a reservation given a ClientList, length of stay and the breakfast option
    func addReservation(clientList:Array<Client>, lengthOfStay:Int, isBreakfastIncluded:Bool) throws -> Reservation {
        // Check for duplicaetd IDs or Clients, throws if happens
        if checkForDuplicateIds() {throw ReservationError.duplicatedID}
        if checkForDuplicateClients(clientList: clientList) {throw ReservationError.duplicatedReservation}
        
        // Compute resulting price
        let totalPrice = self .computeFinalPrice(clientNumber: clientList.count, lengthOfStay: lengthOfStay, isBreakfastIncluded: isBreakfastIncluded)
        
        // Create a reservation and add it to the reservationList
        let reservation = Reservation(ID: uid, hotelName: HotelDetails.name, clientList: clientList, lengthOfStay: lengthOfStay, price: totalPrice, isBreakfastIncluded: isBreakfastIncluded)
        reservationList[uid] = reservation
        
        // Increment the UID so it change every time a new reservation is done
        uid += 1

        return reservation
    }
    /// Removes a reservation given its ID
    func cancelReservation(id:Int) throws {
        if !reservationList.keys.contains(id) {throw ReservationError.ReservationNotFound}
        reservationList.removeValue(forKey: id)
    }
    /// Returns the reservationList (as a dictionary)
    func getReservations() -> [Int: Reservation] {
        return reservationList
    }
    /// Returns reservationList as an array
    func getReservationsAsArray() -> Array<Reservation> {
        return Array(reservationList.values).reversed()
    }
}

class ValidationTests {
    
    // Create some test Clients
    private let foo = Client (name: "foo", age: 22, height: 185)
    private let bar = Client (name: "bar", age: 22, height: 185)
    private let baz = Client (name: "baz", age: 22, height: 185)
    private let tom = Client (name: "Tom", age: 22, height: 185)
    private let brian = Client (name: "Brian", age: 33, height: 165)
    private let tom2 = Client (name: "Tom", age: 22, height: 185)
    private let biz = Client (name: "biz", age: 22, height: 185)
    private let foobar = Client (name: "foobar", age: 22, height: 185)
    private let qux = Client (name: "qux", age: 22, height: 185)
    
    // Instantiate the HotelReservationManager class so it can be reused by all tests
    private let hotelManager = HotelReservationManager()
    /// Tests if reservations are correctly added and if throws if a duplicated id or client is found
    func testAddReservation() {
        // Push some reservations into an  external array
        do {
            try hotelManager.addReservation(clientList: [foo], lengthOfStay: 3, isBreakfastIncluded: true)
            assert(hotelManager.getReservationsAsArray().count == 1)
            try hotelManager.addReservation(clientList: [bar], lengthOfStay: 3, isBreakfastIncluded: false)
            assert(hotelManager.getReservationsAsArray().count == 2)
            try hotelManager.addReservation(clientList: [baz], lengthOfStay: 1, isBreakfastIncluded: false)
            assert(hotelManager.getReservationsAsArray().count == 3)
            try hotelManager.addReservation(clientList: [tom], lengthOfStay: 5, isBreakfastIncluded: true)
            assert(hotelManager.getReservationsAsArray().count == 4)
            try hotelManager.addReservation(clientList: [brian], lengthOfStay: 7, isBreakfastIncluded: true)
            assert(hotelManager.getReservationsAsArray().count == 5)
            // More than one client
            try hotelManager.addReservation(clientList: [foobar,qux], lengthOfStay: 4, isBreakfastIncluded: false)
            assert(hotelManager.getReservationsAsArray().count == 6)
            // Duplicate entry in given clientList
            try hotelManager.addReservation(clientList: [qux,qux], lengthOfStay: 1, isBreakfastIncluded: false)
            print("this should never be printed")
        } catch {
            let reservationError = error as? ReservationError
            assert(reservationError == .duplicatedReservation)
            switch reservationError {
            case .duplicatedID:
                print("TestAddReservation: \(error): The id for the reservation is already in use. <- This should never happend")
            case .duplicatedReservation:
                print("TestAddReservation: \(error): There's already a reservation for this client <- This should happend once for testing purposes")
            default:
                print(error)
            }
        }
        
        do {
            try hotelManager.addReservation(clientList: [tom2], lengthOfStay: 1, isBreakfastIncluded: false)
            assert(hotelManager.getReservationsAsArray().count == 5) // Duplicate so it should not add a reservation
        } catch {
            let reservationError = error as? ReservationError
            assert(reservationError == .duplicatedReservation)
        }
        
        // Try duplicates with an array of clients
        do {
            try hotelManager.addReservation(clientList: [biz,foo], lengthOfStay: 1, isBreakfastIncluded: false)
            assert(hotelManager.getReservationsAsArray().count == 6)
        } catch {
            let reservationError = error as? ReservationError
            assert(reservationError == .duplicatedReservation)
        }
    }
    /// Tests if reservations can be canceled, efectively removing the entry from the reservations list and throwing when a reservation id does not exist
    func testCancelReservation() {
        let currentReservationsNumber = hotelManager.getReservationsAsArray().count
        do {
            try hotelManager.cancelReservation(id: 3)
            assert(hotelManager.getReservationsAsArray().count == currentReservationsNumber - 1)
            // Let's try to remove the reservation with id 3 again as it should not exists now
            try hotelManager.cancelReservation(id: 3)
        } catch {
            let reservationError = error as? ReservationError
            assert(reservationError == .ReservationNotFound)
            if reservationError == .ReservationNotFound {
                print("TestAddReservation: \(error): The id for the given reservation does not exist <- This should happend once for testing purposes")
            } else {
                print(error)
            }
        }
    }
    /// Test if reservation prices are calculated correctly
    func testReservationPrice() {
        let reservations = hotelManager.getReservations()
        // 3 days 1 person breakfast expected 75
        reservations[0]?.price // This is here for easy check on playground sidebar
        assert(reservations[0]?.price == 75)
        // 3 days 1 person NO breakfast expected 60
        reservations[1]?.price // This is here for easy check on playground sidebar
        assert(reservations[1]?.price == 60)
        // 1 day 1 person NO breakfast expected 20
        reservations[2]?.price // This is here for easy check on playground sidebar
        assert(reservations[2]?.price == 20)
        // 7 days 1 person breakfast expected 175
        reservations[4]?.price // This is here for easy check on playground sidebar
        assert(reservations[4]?.price == 175)
        // 4 days 2 person NO breakfast expected 160
        reservations[5]?.price // This is here for easy check on playground sidebar
        assert(reservations[5]?.price == 160)
    }
}

let validatonTests = ValidationTests();
validatonTests.testAddReservation()
validatonTests.testCancelReservation()
validatonTests.testReservationPrice()
